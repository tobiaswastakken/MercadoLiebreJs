console.log("funciona");

let nombre = prompt("Cual es tu nombre?");
let edad = prompt("Cual es tu edad?");
let estudio = confirm("Estudias?");

if(estudio == true){
  let estudio2 = prompt("Donde estudias?");
  if (edad == 1 ){ 
  console.log(`Mi nombre es ${nombre}, tengo ${edad} año y estudio en ${estudio2}`);
  }
  else{
    console.log(`Mi nombre es ${nombre}, tengo ${edad} años y estudio en ${estudio2}`);
  }
}
else{

  console.log(`Mi nombre es ${nombre}, tengo ${edad} años y no estudio :(`)
}
