let nota = prompt("Cual es tu nota?")


if(nota == 10){
  console.log("Excelente")
}
else if(nota > 6){
  console.log("Muy bien")
}
else if (nota <= 6){
  console.log("Podria ser mejor")
}
else if (nota == 0){
  console.log("Hay que estudiar")
}