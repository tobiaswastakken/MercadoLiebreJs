
let producto = prompt("Ingrese un producto: ");

while(producto != "ESC" || precio != "ESC" ){
  
  let precio = prompt("Ingrese un precio");
  let precio2 = precio * 1
  
  if(Number.isNaN(precio2)){
    alert("Solo se pueden ingresar numeros")
    break
  }

  alert(`Su producto es ${producto} y su precio es de ${precio}`);
  producto = prompt("Ingrese otro producto");

}
