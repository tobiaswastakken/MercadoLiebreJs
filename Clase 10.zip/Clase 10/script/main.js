const carrito = []  
const email = document.getElementById("email");
const password = document.getElementById("password");
const boton = document.getElementById("boton");


let estado = false;
let c = "123"
let u = "jose17"

boton.addEventListener("click", ingresarData);



function ingresarData(){


  let clave = password.value;
  let usuario = email.value;

 while(estado == false ){
  
    if(clave != c && usuario != u){

      alert("Los datos son incorrectos")
      
    }

    else if(clave != c){

      alert("La contraseña es incorrecta")
      

    }

    else if(usuario != u){

      alert("El usuario es incorrecto")
      
    }

    if(clave == c && usuario == u){

      alert("Bienvenidx");
      break  
    }
    
    else{
      estado = true;
    }


  }

 }


 function agregarProducto(){

  const id = prompt("Ingrese un numero");
  const marca = prompt("Ingrese una marca");
  const nombre = prompt("Ingrese un nombre");
  const precio= prompt("Ingrese un precio");



  const productoNuevo = { id : id, marca : marca, nombre : nombre, precio : precio}

  carrito.push(productoNuevo);
  console.log(carrito);


  let listaProductoNuevo = Object.values(productoNuevo);
  console.log(listaProductoNuevo);

 }


crearCosas()

function crearCosas(){
    
    
    const div = document.createElement("div");
    document.body.appendChild(div);
  

    div.className= "alert alert-warning container";


    const ul = document.createElement("ul");
    document.body.appendChild(ul);
    div.appendChild(ul)
      
    const li1 = document.createElement("li");
    const li1Txt = document.createTextNode("TV Samsung");
    li1.appendChild(li1Txt);

    const li2 = document.createElement("li");
    const li2Txt = document.createTextNode("Smart TV 32 pulgadas")
    li2.appendChild(li2Txt);

    const li3 = document.createElement("li");
    const li3Txt = document.createTextNode("65000");
    li3.appendChild(li3Txt);
      
    
    const li4 = document.createElement("li");
    const li4Txt = document.createTextNode("30");
    li4.appendChild(li4Txt);


    const li5 = document.createElement("li");
    const img = document.createElement("img")
    li5.appendChild(img);

    function setAttributes(img, atributos) {
      for(let x in atributos) {
        img.setAttribute(x, atributos[x]);
      }
    }

    setAttributes(img, {"src": "img/productos/Captura de pantalla_20230202_053725.png", "alt": "Imagen de una TV"});

    
    ul.appendChild(li1);
    ul.appendChild(li2);
    ul.appendChild(li3);
    ul.appendChild(li4);
    ul.appendChild(li5);




    const agregarCarrito = document.createElement("BUTTON");
    agregarCarrito.innerText = "Agregar al carrito"

    agregarCarrito.addEventListener("click", agregarProducto)


    div.appendChild(agregarCarrito, crearLista)
    console.log(ul.parentNode);


   
    

   
  function crearLista(){

    const ul2 = document.createElement("ul");
    document.body.appendChild(ul2);
    div.appendChild(ul2);

    

    listaProductoNuevo.forEach(eleme => {
      
    const nuevo = document.createElement('li');
    
    
    nuevo.innerText = "hola"

    ul2.appendChild(nuevo)
    });

      
    };    

  };


  
  
  
  
  
