alert("Bienvenidx a DW2")
prompt("Ingresa tu nombre")
confirm("Estas listo para comenzar?")

console.log("JavaScript es genial!")