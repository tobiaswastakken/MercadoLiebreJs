const email = document.getElementById("email");
const password = document.getElementById("password");
const boton = document.getElementById("boton");


let estado = false;
let c = "123"
let u = "jose17"

boton.addEventListener("click", ingresarData);


function ingresarData(){


  let clave = password.value;
  let usuario = email.value;

 while(estado == false ){
  
    if(clave != c && usuario != u){

      alert("Los datos son incorrectos")
      
    }

    else if(clave != c){

      alert("La contraseña es incorrecta")
      

    }

    else if(usuario != u){

      alert("El usuario es incorrecto")
      
    }

    if(clave == c && usuario == u){

      alert("Bienvenidx");
      break  
    }
    
    else{
      estado = true;
    }


  }

 }