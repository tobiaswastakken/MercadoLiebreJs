const carrito = []  
const email = document.getElementById("email");
const password = document.getElementById("password");
const boton = document.getElementById("boton");


let estado = false;
let c = "123"
let u = "jose17"

boton.addEventListener("click", ingresarData);



function ingresarData(){


  let clave = password.value;
  let usuario = email.value;

 while(estado == false ){
  
    if(clave != c && usuario != u){

      alert("Los datos son incorrectos")
      
    }

    else if(clave != c){

      alert("La contraseña es incorrecta")
      

    }

    else if(usuario != u){

      alert("El usuario es incorrecto")
      
    }

    if(clave == c && usuario == u){

      alert("Bienvenidx");
      break  
    }
    
    else{
      estado = true;
    }


  }

 }

 agregarProdcuto()

 function agregarProdcuto(){

  const id = prompt("Ingrese un numero");
  const marca = prompt("Ingrese una marca");
  const nombre = prompt("Ingrese un nombre");
  const precio= prompt("Ingrese un precio");



  const productoNuevo = { id : id, marca : marca, nombre : nombre, precio : precio}

  carrito.push(productoNuevo);
  console.log(carrito)

 }







 const cafetera = {
  color : "rojo", potenciaWatts : 1340, material : "plastico", pesoEnKg : 2.5, precio : 35000
 }
 
 const MacBookPro = {
  color : "gris", memoriaRam : 8, pantallaTactil : true, capacidadAlmacenamiento : 256
 }